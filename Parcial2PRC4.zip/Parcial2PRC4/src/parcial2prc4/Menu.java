package parcial2prc4;
import java.util.Scanner;
import java.io.*;
import java.util.Scanner;
//import Parcial2PRC4.LeeFichero;

public class Menu {
    void MenuA()// Menu de admin
    { 
        int op=0;
        Scanner leer=new Scanner(System.in);
        System.out.println("**Menú de opciones***"); 
        System.out.println("1.Paciente");
        System.out.println("2.Citas");
        System.out.println("3.Medicos");
        System.out.println("4.Horarios");
        System.out.println("5.Alergias");
        System.out.println("6.Salir");
        op=leer.nextInt();
        System.out.println(new String(new char[1]).replace("\0", "\r\n"));

        // procesos
        switch (op){
            case 1:
                //pacientes
                System.out.println("1.Agregar paciente"); 
                System.out.println("2.Editar paciente");
                System.out.println("3.Ver lista de pacientes");
                System.out.println("Digite la opción");
                op=leer.nextInt();
                System.out.println(new String(new char[1]).replace("\0", "\r\n"));
                //System.out.println("xx.Eliminar paciente");  no deberia porque es un historial medico OSEA
            switch (op){
                case 1://Agregar
                break;
                case 2://Editar
                break;
                case 3://Ver Lista
                break;
            }
            case 2:
                //citas
                System.out.println("1.Agregar cita");
                System.out.println("2.Editar cita");
                System.out.println("3.Eliminar cita");
                System.out.println("4.Ver lista de citas");
                System.out.println("Digite la opción");
                op=leer.nextInt();
                System.out.println(new String(new char[1]).replace("\0", "\r\n"));
                switch (op){
                case 1://Agregar
                break;
                case 2://Editar
                break;
                case 3://Eliminar
                break;
                case 4://Ver Lista
                break;
            }
            break;
            case 3:
                 //medicos
                System.out.println("1.Agregar medico");       
                System.out.println("2.Editar medico");
                System.out.println("3.Eliminar medico");
                System.out.println("4.Ver lista de medicos");
                System.out.println("Digite la opción");
                op=leer.nextInt();
                System.out.println(new String(new char[1]).replace("\0", "\r\n"));
                switch (op){
                case 1://Agregar
                break;
                case 2://Editar
                break;
                case 3://Eliminar
                break;
                case 4://Ver Lista
                break;
            }
            break;
            case 4:
                //horarios
                System.out.println("1.Agregar horario");
                System.out.println("2.Editar horario"); 
                System.out.println("3.Eliminar horario");
                System.out.println("4.Ver horario"); 
                System.out.println("Digite la opción");
                op=leer.nextInt();
                System.out.println(new String(new char[1]).replace("\0", "\r\n"));
                switch (op){
                case 1://Agregar
                break;
                case 2://Editar
                break;
                case 3://Eliminar
                break;
                case 4://Ver Horario
                break;
            }
            break;
            case 5:
                //alergia
                System.out.println("1.Agregar alergia");
                System.out.println("2.Editar alergia");
                System.out.println("3.Eliminar alergia");
                System.out.println("4.Ver Alergias");
                System.out.println("Digite la opción");
                op=leer.nextInt();
                System.out.println(new String(new char[1]).replace("\0", "\r\n"));
                switch (op){
                case 1://Agregar
                break;
                case 2://Editar
                break;
                case 3://Eliminar
                break;
                case 4://Ver Alergias
                break;
            }
            break;
            case 6://Salir
                System.out.println("Saliendo del sistema"); 
                break;
            default:
                System.out.println("Opción no valida");
                break;
        }        
    }   
    void MenuM()//Menu para medico
    {
        int op=0;
        Scanner leer=new Scanner(System.in);
        System.out.println("**Menú de opciones***"); 
        System.out.println("1.Paciente");
        System.out.println("2.Citas");
        System.out.println("3.Horarios");
        System.out.println("4.Alergias");
        System.out.println("5.Salir");
        op=leer.nextInt();
        System.out.println(new String(new char[1]).replace("\0", "\r\n"));
        // procesos
        switch (op){
            case 1:
                //pacientes
                System.out.println("1.Agregar paciente"); 
                System.out.println("2.Editar paciente");
                System.out.println("3.Ver lista de pacientes");         
                System.out.println("Digite la opción");
                op=leer.nextInt();
                System.out.println(new String(new char[1]).replace("\0", "\r\n"));
            switch (op){
                case 1://Agregar
                break;
                case 2://Editar
                break;
                case 3://Ver Lista
                break;
            }
            break;
            case 2:
                //citas
                System.out.println("1.Agregar cita");
                System.out.println("2.Editar cita");
                System.out.println("3.Eliminar cita");
                System.out.println("4.Ver lista de citas");
                System.out.println("Digite la opción");
                op=leer.nextInt();
                System.out.println(new String(new char[1]).replace("\0", "\r\n"));
                switch (op){
                case 1://Agregar
                break;
                case 2://Editar
                break;
                case 3://Eliminar
                break;
                case 4://Ver Lista
                break;
            }
            break;
            case 3:
                      //horarios
                System.out.println("1.Agregar horario");
                System.out.println("2.Editar horario"); 
                System.out.println("3.Eliminar horario");
                System.out.println("4.Ver horario"); 
                System.out.println("Digite la opción");
                op=leer.nextInt();
                System.out.println(new String(new char[1]).replace("\0", "\r\n"));
                switch (op){
                case 1://Agregar
                break;
                case 2://Editar
                break;
                case 3://Eliminar
                break;
                case 4://Ver Horario
                break;
            }
            break;
            case 4:
                 //alergia
                System.out.println("1.Agregar alergia");
                System.out.println("2.Editar alergia");
                System.out.println("3.Eliminar alergia");
                System.out.println("4.Ver Alergias");
                System.out.println("Digite la opción");
                op=leer.nextInt();
                System.out.println(new String(new char[1]).replace("\0", "\r\n"));
                switch (op){
                case 1://Agregar
                break;
                case 2://Editar
                break;
                case 3://Eliminar
                break;
                case 4://Ver Alergias
                break;
            }
            break;
            case 5://Salir
                System.out.println("Saliendo del sistema"); 
                break;
            default:
                System.out.println("Opción no valida");
                break;
        }        
    } 
    
    void MenuS()// Menu para asistente
    { int op=0;
        Scanner leer=new Scanner(System.in);
        System.out.println("**Menú de opciones***"); 
        System.out.println("1.Paciente");
        System.out.println("2.Citas");
        System.out.println("3.Horarios");
        System.out.println("4.Alergias");
        System.out.println("5.Salir");
        op=leer.nextInt();
        System.out.println(new String(new char[1]).replace("\0", "\r\n"));
        // procesos
        switch (op){
            case 1:
                //pacientes
                System.out.println("1.Agregar paciente"); 
                System.out.println("2.Editar paciente");
                System.out.println("3.Ver lista de pacientes");         
                System.out.println("Digite la opción");
                op=leer.nextInt();
                System.out.println(new String(new char[1]).replace("\0", "\r\n"));
            switch (op){
                case 1://Agregar
                break;
                case 2://Editar
                break;
                case 3://Ver Lista
                break;
            }
            break;
            case 2:
                //citas
                System.out.println("1.Agregar cita");
                System.out.println("2.Editar cita");
                System.out.println("3.Eliminar cita");
                System.out.println("4.Ver lista de citas");
                System.out.println("Digite la opción");
                op=leer.nextInt();
                System.out.println(new String(new char[1]).replace("\0", "\r\n"));
                switch (op){
                case 1://Agregar
                break;
                case 2://Editar
                break;
                case 3://Eliminar
                break;
                case 4://Ver Lista
                break;
            }
            break;
            case 3:
                      //horarios
                System.out.println("1.Agregar horario");
                System.out.println("2.Editar horario"); 
                System.out.println("3.Eliminar horario");
                System.out.println("4.Ver horario"); 
                System.out.println("Digite la opción");
                op=leer.nextInt();
                System.out.println(new String(new char[1]).replace("\0", "\r\n"));
                switch (op){
                case 1://Agregar
                break;
                case 2://Editar
                break;
                case 3://Eliminar
                break;
                case 4://Ver Horario
                break;
            }
            break;
            case 4:
                 //alergia
                System.out.println("1.Agregar alergia");
                System.out.println("2.Editar alergia");
                System.out.println("3.Eliminar alergia");
                System.out.println("4.Ver Alergias");
                System.out.println("Digite la opción");
                op=leer.nextInt();
                System.out.println(new String(new char[1]).replace("\0", "\r\n"));
                switch (op){
                case 1://Agregar
                break;
                case 2://Editar
                break;
                case 3://Eliminar
                break;
                case 4://Ver Alergias
                break;
            }
            break;
            case 5://Salir
                System.out.println("Saliendo del sistema"); 
                break;
            default:
                System.out.println("Opción no valida");
                break;
            }       
        }
    }        