package parcial2prc4;
import static java.lang.Math.max;
import static java.lang.Math.min;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Bitacora {
    static Logger bitacora = ManejaBitacora.getBitacora("parcial2prc4","Registro.txt",Level.FINE);
    public static int getInfo(String Admin, String vendedor, String Invitado ){
        if (){
               bitacora.severe("Su registro"+Admin+"Cerrando");
               bitacora.info("Ok");
               double dblRandom = Math.random();
               bitacora.fine("dblRandom"+dblRandom);
               int largo = max - min -1 ;
               bitacora.fine("Largo:"+dblRandom);
               double offset = largo * dblRandom;
               bitacora.fine("offset:"+offset);
               int entOffset = (int)offset;
               bitacora.fine("entOffset:"+ entOffset);
               
               int entRandom = entOffset + min + 1;
               return entRandom;   
             }
        return 0;
    }    
}

