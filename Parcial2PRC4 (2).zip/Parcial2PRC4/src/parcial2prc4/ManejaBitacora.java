package parcial2prc4;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ManejaBitacora {
        static Logger getBitacora(){
        return Logger.getGlobal();
    }
        static Logger getBitacora(String grupo, String NombreBitacora, Level nivel){
        Logger bitacora = null;
        try {
            FileHandler handler = new FileHandler(NombreBitacora);
            bitacora.addHandler(handler);
            }
        catch(IOException e){
            bitacora = Logger.getGlobal();
            bitacora.severe("Error al crear bitacora"+ e.getMessage());
            return bitacora;
            } 
        bitacora.setLevel(nivel);
        return bitacora;
    }  
}